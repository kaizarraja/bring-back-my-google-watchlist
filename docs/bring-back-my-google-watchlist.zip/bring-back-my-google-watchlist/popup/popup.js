// Toolbar popup: the full list, sign-in for syncing, and backup and import.

(() => {
  const { el } = WLUI;
  const app = document.getElementById('app');
  app.className = 'wl-root';
  const darkQuery = matchMedia('(prefers-color-scheme: dark)');
  const applyTheme = () => { app.dataset.theme = darkQuery.matches ? 'dark' : 'light'; };
  darkQuery.addEventListener('change', applyTheme);
  applyTheme();

  const style = document.createElement('style');
  style.textContent = WLUI.CSS;
  document.head.prepend(style);

  const status = el('div', { class: 'wl-status', role: 'status' });
  const fileInput = el('input', { type: 'file', accept: '.json,application/json', hidden: true, onchange: importFile });

  const syncText = el('span', { class: 'wl-sync-text' });
  const signInButton = el('button', { class: 'wl-chip wl-primary', type: 'button', text: 'Sign in with Google to sync', onclick: signIn });
  const syncNowButton = el('button', { class: 'wl-link', type: 'button', text: 'Sync now', onclick: () => send('sync-now') });
  const signOutButton = el('button', { class: 'wl-link', type: 'button', text: 'Sign out', onclick: () => send('sign-out') });
  const deleteButton = el('button', { class: 'wl-link', type: 'button', text: 'Delete synced data', onclick: deleteSynced });
  const syncRow = el('div', { class: 'wl-sync' }, [syncText, signInButton, syncNowButton, signOutButton, deleteButton]);

  // "Version 0.5.1 · Check for updates", or "Update to 0.6.0 →" when one is out.
  const currentVersion = chrome.runtime.getManifest().version;
  const updateLink = el('a', { class: 'wl-link wl-update-link', href: WL_CONFIG.updatePage, target: '_blank', rel: 'noopener' });
  const checkButton = el('button', { class: 'wl-link', type: 'button', text: 'Check for updates', onclick: checkNow });
  const versionText = el('span', { class: 'wl-version', text: `Version ${currentVersion}` });
  // Opens this extension's own page in the browser's extensions settings (reload, remove,
  // site access). chrome:// works in Chrome, Brave, Edge and other Chromium browsers, which
  // send it to their own brave:// or edge:// page.
  const manageButton = el('button', {
    class: 'wl-link', type: 'button', text: 'Manage extension', title: "Open this extension's settings page",
    onclick: () => chrome.tabs.create({ url: `chrome://extensions/?id=${chrome.runtime.id}` }),
  });
  const versionRow = el('div', { class: 'wl-version-row' }, [versionText, updateLink, checkButton, manageButton]);

  app.append(
    WLUI.createListView({ openInNewTab: true, showSearch: true }),
    el('footer', { class: 'wl-footer' }, [
      syncRow,
      el('button', { class: 'wl-link', type: 'button', text: 'Export', title: 'Save a backup file of your watchlist', onclick: exportFile }),
      el('button', { class: 'wl-link', type: 'button', text: 'Import file', title: 'Load a backup file', onclick: () => fileInput.click() }),
      el('a', { class: 'wl-link', href: chrome.runtime.getURL('welcome/welcome.html'), target: '_blank', text: 'Getting started' }),
      status,
      versionRow,
      fileInput,
    ]),
  );

  function send(type) {
    return chrome.runtime.sendMessage({ type });
  }

  async function signIn() {
    signInButton.disabled = true;
    syncText.textContent = 'Signing in…';
    const res = await send('sign-in');
    signInButton.disabled = false;
    if (!res.ok) syncText.textContent = /did not approve|canceled|cancelled/i.test(res.error) ? 'Sign-in was cancelled.' : 'Sign-in failed: ' + res.error;
  }

  const ago = (t) => {
    const s = Math.round((Date.now() - t) / 1000);
    if (s < 60) return 'just now';
    if (s < 3600) return `${Math.round(s / 60)} min ago`;
    return new Date(t).toLocaleString();
  };

  async function showSync() {
    const { auth, 'sync:status': st } = await chrome.storage.local.get(['auth', 'sync:status']);
    signInButton.hidden = Boolean(auth);
    syncNowButton.hidden = !auth;
    signOutButton.hidden = !auth;
    deleteButton.hidden = !auth;
    if (!auth) {
      syncText.textContent = st && st.error ? st.error : 'Your list is only on this browser.';
    } else if (st && st.error) {
      syncText.textContent = `Signed in as ${auth.email} · couldn't sync: ${st.error}`;
    } else {
      syncText.textContent = `Synced as ${auth.email}` + (st && st.at ? ` · ${ago(st.at)}` : '');
    }
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && ('auth' in changes || 'sync:status' in changes)) showSync();
  });
  showSync();
  send('sync-now');

  async function deleteSynced() {
    if (!confirm('Delete your list from the sync server? Every signed-in browser will be signed out. The list on this browser stays, and you can sign in again to start syncing afresh.')) return;
    const res = await send('delete-account');
    status.textContent = res.ok ? 'Your synced data was deleted from the server.' : "Couldn't delete: " + res.error;
  }

  async function showVersion(justChecked = false) {
    const { 'update:latest': latest } = await chrome.storage.local.get('update:latest');
    const newer = latest && WL.isNewerVersion(latest.version, currentVersion);
    updateLink.hidden = !newer;
    checkButton.hidden = Boolean(newer);
    if (newer) updateLink.textContent = `Update to version ${latest.version} →`;
    versionText.textContent = `Version ${currentVersion}` + (justChecked && !newer ? ' · You have the latest version' : '');
  }

  async function checkNow() {
    checkButton.disabled = true;
    checkButton.textContent = 'Checking…';
    await send('check-update');
    checkButton.disabled = false;
    checkButton.textContent = 'Check for updates';
    showVersion(true);
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && 'update:latest' in changes) showVersion();
  });
  showVersion();
  // Opening the popup is a good moment to look for a newer version; the banner above the
  // list and the update link appear as soon as the check finds one.
  send('check-update');

  async function exportFile() {
    const items = (await WL.getAll()).map(({ poster, ...rest }) => rest);
    const blob = new Blob([JSON.stringify({ app: 'my-watchlist', version: 1, exportedAt: new Date().toISOString(), items }, null, 2)], { type: 'application/json' });
    const a = el('a', { href: URL.createObjectURL(blob), download: `my-watchlist-${new Date().toISOString().slice(0, 10)}.json` });
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 10000);
    status.textContent = `Exported ${items.length} titles.`;
  }

  async function importFile() {
    const file = fileInput.files[0];
    fileInput.value = '';
    if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      const raw = Array.isArray(data) ? data : data.items;
      if (!Array.isArray(raw)) throw new Error('This file has no list of titles in it.');
      const items = raw
        .filter((i) => i && typeof i.title === 'string' && i.title.trim())
        .map((i) => ({
          id: typeof i.id === 'string' ? i.id : null,
          title: i.title.trim(),
          year: Number(i.year) || null,
          kind: i.kind === 'tv' || i.kind === 'movie' ? i.kind : null,
          addedAt: Number(i.addedAt) || null,
          watchedAt: Number(i.watchedAt) || null,
        }));
      const r = await WL.addMany(items);
      status.textContent = `Imported ${r.added} titles` +
        (r.skipped ? `, ${r.skipped} were already on your list` : '') + '.';
    } catch (err) {
      status.textContent = 'Could not import that file: ' + (err.message || err);
    }
  }

})();
